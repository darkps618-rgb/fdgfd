# AskAI Chat – Minecraft 26.3 (Fabric, client mod)

Press **Insert** in a world to open a messenger-style AI chat window.
Your messages are on the right (blue), the AI's are on the left.
The AI answers kindly and gives the exact command for what you want to do.

## In the window
- Enter or Send  – send your message
- Click a green command line – copy it (then paste into game chat with T / Ctrl+V)
- Copy cmd – copy the latest command the AI suggested
- Clear – start a new conversation
- Mouse wheel / Page Up / Page Down – scroll
- Insert or Esc – close
- Change the hotkey in Options > Controls > Key Binds > AI Chat

## Build
1. JDK 25 required.
2. Run `gradle wrapper` once, then `./gradlew build` (or use IntelliJ's Gradle `build` task).
3. Put `build/libs/askai-1.0.0.jar` in `mods/` with Fabric Loader 0.19+ and Fabric API for 26.3.

## Setup
Launch once, then paste your Anthropic API key (console.anthropic.com) into
`config/askai.json` (or set ANTHROPIC_API_KEY) and restart.
This is a client mod: it works in singleplayer and on any server, nothing to install server-side.
Keep your key private; every message uses API credit.
