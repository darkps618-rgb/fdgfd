package com.example.askai;

import java.util.ArrayList;
import java.util.List;

/** Chat history lives here (not in the screen) so it survives closing and reopening the window. */
public final class ChatState {
    public record Row(String text, boolean cmd, String full) {}

    public static final class Msg {
        public final boolean ai;
        public final String text;
        public boolean api;           // included when talking to the API
        public final boolean error;
        // layout cache, filled by the screen
        public int lw = -1, bw, bh;
        public List<Row> rows = List.of();

        Msg(boolean ai, String text, boolean api, boolean error) {
            this.ai = ai; this.text = text; this.api = api; this.error = error;
        }
    }

    public static final List<Msg> MESSAGES = new ArrayList<>();
    public static volatile boolean waiting = false;
    public static int generation = 0;

    private static final String GREETING =
        "Hi there! I'm your AI assistant. Ask me anything, from Minecraft questions to everyday ones. "
      + "If you want to do something in the game, I'll tell you the exact command.\n"
      + "Try: how do I give myself a diamond sword?";

    static { reset(); }

    public static void reset() {
        generation++;
        waiting = false;
        MESSAGES.clear();
        MESSAGES.add(new Msg(true, GREETING, false, false));
    }

    public static Msg addUser(String text) {
        Msg m = new Msg(false, text, true, false);
        MESSAGES.add(m);
        return m;
    }

    /** Returns true if the result was applied (chat was not cleared meanwhile). */
    public static boolean finish(int gen, Msg userMsg, String answer, Throwable err) {
        if (gen != generation) return false;
        waiting = false;
        if (err != null) {
            userMsg.api = false;
            Throwable c = err.getCause() != null ? err.getCause() : err;
            String msg = c.getMessage() == null ? c.toString() : c.getMessage();
            MESSAGES.add(new Msg(true, "Sorry, something went wrong: " + msg, false, true));
        } else {
            String cleaned = clean(answer);
            MESSAGES.add(new Msg(true, cleaned.isBlank() ? "(no answer)" : cleaned, true, false));
        }
        return true;
    }

    public static List<String[]> apiHistory(int max) {
        List<String[]> out = new ArrayList<>();
        for (Msg m : MESSAGES) if (m.api) out.add(new String[]{m.ai ? "assistant" : "user", m.text});
        while (out.size() > max) out.remove(0);
        while (!out.isEmpty() && out.get(0)[0].equals("assistant")) out.remove(0);
        return out;
    }

    /** The most recent command line the AI suggested, or null. */
    public static String lastCommand() {
        for (int i = MESSAGES.size() - 1; i >= 0; i--) {
            Msg m = MESSAGES.get(i);
            if (!m.ai || m.error) continue;
            String[] lines = m.text.split("\n");
            for (int j = lines.length - 1; j >= 0; j--) {
                String t = lines[j].strip();
                if (t.startsWith("/") && t.length() > 1) return t;
            }
        }
        return null;
    }

    static String clean(String s) {
        String t = s.replace("\r", "").replace("**", "").replace("__", "").replace("`", "");
        t = t.replaceAll("(?m)^#+\\s*", "");
        t = t.replaceAll("(?m)^\\s*[-*]\\s+", "\u2022 ");
        return t.strip();
    }

    private ChatState() {}
}
