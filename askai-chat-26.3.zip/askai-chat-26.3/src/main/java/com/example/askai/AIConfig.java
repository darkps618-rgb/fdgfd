package com.example.askai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class AIConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public String apiKey = "PUT_YOUR_ANTHROPIC_API_KEY_HERE";
    public String model = "claude-sonnet-5-5";
    public int maxTokens = 800;
    public int historyMessages = 14;
    public String systemPrompt =
        "You are a warm, gentle and patient AI assistant chatting with a player inside Minecraft "
      + "Java Edition 26.3. Answer any question on any topic accurately and kindly, the way a "
      + "thoughtful friend would. If the player seems frustrated or stuck, be reassuring. "
      + "Whenever the player wants to do something in the game (give items, change gamemode, time, "
      + "weather, teleport, summon, gamerules, effects, enchantments, structures and so on), tell them "
      + "the exact command for it. Put every command on its own line that starts with / and contains "
      + "nothing else, then add one short friendly sentence explaining it. Mention when a command needs "
      + "cheats enabled or operator permission. If you are not fully sure about the exact current syntax, "
      + "say so honestly and suggest typing /help <command> or using Tab to autocomplete. "
      + "Replies show in a small chat window: keep them short and clear, use plain text only "
      + "(no markdown, no asterisks, no backticks, no headings).";

    public static AIConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("askai.json");
        try {
            if (Files.exists(path)) {
                AIConfig cfg = GSON.fromJson(Files.readString(path), AIConfig.class);
                if (cfg != null) return cfg;
            }
            AIConfig cfg = new AIConfig();
            Files.writeString(path, GSON.toJson(cfg));
            return cfg;
        } catch (Exception e) {
            AskAIClient.LOGGER.error("Could not read askai.json, using defaults", e);
            return new AIConfig();
        }
    }

    /** Config value first, then the ANTHROPIC_API_KEY environment variable. */
    public String resolveApiKey() {
        if (apiKey != null && !apiKey.isBlank() && !apiKey.startsWith("PUT_YOUR")) return apiKey.trim();
        String env = System.getenv("ANTHROPIC_API_KEY");
        return env == null ? "" : env.trim();
    }
}
