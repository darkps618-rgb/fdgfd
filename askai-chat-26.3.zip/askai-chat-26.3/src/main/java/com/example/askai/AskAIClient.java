package com.example.askai;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AskAIClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("askai");
    public static AIConfig config;
    private static KeyMapping openKey;

    @Override
    public void onInitializeClient() {
        config = AIConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("askai", "chat"));
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.askai.open", InputConstants.Type.KEYSYM, InputConstants.KEY_INSERT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.consumeClick()) {
                if (client.player != null && client.gui.screen() == null) {
                    client.gui.setScreen(new AIChatScreen());
                }
            }
        });
        LOGGER.info("AskAI Chat loaded. Press Insert in-game to open it.");
    }
}
